// For OpenTK visualization (and debugging)
public IEnumerable<(float x, float y, float z)> ParticlesForVisualization()
{
    // TODO: Adjust field/property names below to match your Particle type.
    foreach (var p in _particles)
        yield return ((float)p.Pos.X, (float)p.Pos.Y, (float)p.Pos.Z);
}
