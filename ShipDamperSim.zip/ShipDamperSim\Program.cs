using System.Text.Json;

namespace ShipDamperSim;

internal static class Program
{
    static int Main(string[] args)
    {
        try
        {
            string configPath = args.Length > 0 ? args[0] : "config.json";
            var json = File.ReadAllText(configPath);
            var cfg = JsonSerializer.Deserialize<SimConfig>(json, SimConfig.JsonOptions)
                      ?? throw new Exception("Invalid config.json");

            Directory.CreateDirectory(cfg.Output.OutputDir);

            // If config was not given as argument, allow interactive adjustment
            if (args.Length == 0)
            {
                Console.WriteLine("--- Damper and Ship Parameter Setup ---");
                cfg.Damper.Enabled = PromptString($"Damper enabled (true/false) [default {cfg.Damper.Enabled}]: ", cfg.Damper.Enabled.ToString()).ToLower() == "true";
                cfg.Damper.CenterY = PromptDouble($"Damper center Y [default {cfg.Damper.CenterY}]: ", cfg.Damper.CenterY);
                cfg.Damper.CenterZ = PromptDouble($"Damper center Z [default {cfg.Damper.CenterZ}]: ", cfg.Damper.CenterZ);
                cfg.Damper.SizeY = PromptDouble($"Damper size Y [default {cfg.Damper.SizeY}]: ", cfg.Damper.SizeY);
                cfg.Damper.SizeZ = PromptDouble($"Damper size Z [default {cfg.Damper.SizeZ}]: ", cfg.Damper.SizeZ);
                cfg.Damper.FillRatio = PromptDouble($"Damper fill ratio (0-1) [default {cfg.Damper.FillRatio}]: ", cfg.Damper.FillRatio);
                cfg.Damper.Radius = PromptDouble($"Grain radius [default {cfg.Damper.Radius}]: ", cfg.Damper.Radius);
                cfg.Damper.Density = PromptDouble($"Grain density [default {cfg.Damper.Density}]: ", cfg.Damper.Density);
                cfg.Damper.Mu = PromptDouble($"Friction coefficient [default {cfg.Damper.Mu}]: ", cfg.Damper.Mu);
                cfg.Damper.Kn = PromptDouble($"Normal stiffness Kn [default {cfg.Damper.Kn}]: ", cfg.Damper.Kn);
                cfg.Damper.GammaN = PromptDouble($"Normal damping GammaN [default {cfg.Damper.GammaN}]: ", cfg.Damper.GammaN);
                cfg.Damper.Kt = PromptDouble($"Tangential stiffness Kt [default {cfg.Damper.Kt}]: ", cfg.Damper.Kt);
                cfg.Damper.Gt = PromptDouble($"Tangential damping Gt [default {cfg.Damper.Gt}]: ", cfg.Damper.Gt);
                cfg.Damper.MaxParticleSpeed = PromptDouble($"Max particle speed [default {cfg.Damper.MaxParticleSpeed}]: ", cfg.Damper.MaxParticleSpeed);
                cfg.Ship.Inertia = PromptDouble($"Ship inertia [default {cfg.Ship.Inertia}]: ", cfg.Ship.Inertia);
                cfg.Ship.HydroDamping = PromptDouble($"Hydrodynamic damping [default {cfg.Ship.HydroDamping}]: ", cfg.Ship.HydroDamping);
                cfg.Ship.Restoring = PromptDouble($"Restoring stiffness [default {cfg.Ship.Restoring}]: ", cfg.Ship.Restoring);
                cfg.Ship.Phi0Deg = PromptDouble($"Initial roll angle phi0 (deg) [default {cfg.Ship.Phi0Deg}]: ", cfg.Ship.Phi0Deg);
                cfg.Ship.PhiDot0DegPerS = PromptDouble($"Initial roll rate phiDot0 (deg/s) [default {cfg.Ship.PhiDot0DegPerS}]: ", cfg.Ship.PhiDot0DegPerS);
                cfg.Excitation.Type = PromptString($"Excitation type (none/sine) [default {cfg.Excitation.Type}]: ", cfg.Excitation.Type);
                if (cfg.Excitation.Type == "sine")
                {
                    cfg.Excitation.M0 = PromptDouble($"Sine moment amplitude [default {cfg.Excitation.M0}]: ", cfg.Excitation.M0);
                    cfg.Excitation.FreqHz = PromptDouble($"Sine frequency (Hz) [default {cfg.Excitation.FreqHz}]: ", cfg.Excitation.FreqHz);
                }
                cfg.Output.OutputDir = PromptString($"Output directory [default {cfg.Output.OutputDir}]: ", cfg.Output.OutputDir);
                cfg.Output.CsvFile = PromptString($"Output CSV file [default {cfg.Output.CsvFile}]: ", cfg.Output.CsvFile);
                Console.WriteLine();
            }

            // If Experiment is set in config, run it automatically
            if (!string.IsNullOrWhiteSpace(cfg.Experiment))
            {
                switch (cfg.Experiment.ToLowerInvariant())
                {
                    case "single":
                        var sim = new Simulation(cfg);
                        using (var vis = new Visualization3D(sim))
                            vis.Run();
                        return 0;
                    case "single_no_vis":
                        var sim2 = new Simulation(cfg);
                        sim2.Run();
                        Console.WriteLine($"Simulation complete. Results in {cfg.Output.OutputDir}/{cfg.Output.CsvFile}");
                        return 0;
                    case "sweep":
                        double[] sweep = new double[] { 0.2, 0.4, 0.6, 0.8 };
                        ExperimentRunner.SweepFillRatio(cfg, sweep, "sweep_results");
                        Console.WriteLine("Sweep complete. Results in sweep_results/.");
                        return 0;
                    case "roll_decay":
                        ExperimentRunner.RollDecay(cfg, "roll_decay_results");
                        return 0;
                    case "harmonic":
                        ExperimentRunner.HarmonicExcitation(cfg, "harmonic_excitation_results");
                        return 0;
                    default:
                        Console.Error.WriteLine($"Unknown experiment type: {cfg.Experiment}");
                        return 1;
                }
            }

            // Choose experiment type
            Console.WriteLine("Choose experiment:");
            Console.WriteLine("1 = Single run with visualization");
            Console.WriteLine("2 = Parameter sweep (fill ratio)");
            Console.WriteLine("3 = Roll decay (no waves, initial push)");
            Console.WriteLine("4 = Harmonic excitation (sine wave)");
            Console.Write("Selection [1]: ");
            var expSel = Console.ReadLine();
            if (expSel == "2")
            {
                double[] sweep = new double[] { 0.2, 0.4, 0.6, 0.8 };
                ExperimentRunner.SweepFillRatio(cfg, sweep, "sweep_results");
                Console.WriteLine("Sweep complete. Results in sweep_results/.");
            }
            else if (expSel == "3")
            {
                ExperimentRunner.RollDecay(cfg, "roll_decay_results");
            }
            else if (expSel == "4")
            {
                ExperimentRunner.HarmonicExcitation(cfg, "harmonic_excitation_results");
            }
            else
            {
                var sim = new Simulation(cfg);
                using var vis = new Visualization3D(sim);
                vis.Run();
            }
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }

        // --- Helper methods for prompting ---
        static double PromptDouble(string prompt, double def)
        {
            Console.Write(prompt);
            var s = Console.ReadLine();
            if (double.TryParse(s, out var v)) return v;
            return def;
        }
        static string PromptString(string prompt, string def)
        {
            Console.Write(prompt);
            var s = Console.ReadLine();
            return string.IsNullOrWhiteSpace(s) ? def : s;
        }
    }
}
