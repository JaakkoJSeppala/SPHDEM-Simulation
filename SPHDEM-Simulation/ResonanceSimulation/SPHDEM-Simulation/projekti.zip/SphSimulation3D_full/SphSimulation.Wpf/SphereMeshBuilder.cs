// SphereMeshBuilder.cs
using System;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace SphSimulation.Wpf
{
    public static class SphereMeshBuilder
    {
        public static MeshGeometry3D CreateSphereMesh(Point3D center, double radius, int slices = 12, int stacks = 8)
        {
            var mesh = new MeshGeometry3D();

            for (int stack = 0; stack <= stacks; stack++)
            {
                double phi = Math.PI * stack / stacks;
                double y = Math.Cos(phi);
                double r = Math.Sin(phi);

                for (int slice = 0; slice <= slices; slice++)
                {
                    double theta = 2.0 * Math.PI * slice / slices;
                    double x = r * Math.Cos(theta);
                    double z = r * Math.Sin(theta);

                    var p = new Point3D(
                        center.X + radius * x,
                        center.Y + radius * y,
                        center.Z + radius * z);

                    mesh.Positions.Add(p);
                    mesh.Normals.Add(new Vector3D(x, y, z));
                    mesh.TextureCoordinates.Add(new System.Windows.Point(
                        (double)slice / slices,
                        (double)stack / stacks));
                }
            }

            int rowLength = slices + 1;
            for (int stack = 0; stack < stacks; stack++)
            {
                for (int slice = 0; slice < slices; slice++)
                {
                    int i0 = stack * rowLength + slice;
                    int i1 = i0 + 1;
                    int i2 = i0 + rowLength;
                    int i3 = i2 + 1;

                    mesh.TriangleIndices.Add(i0);
                    mesh.TriangleIndices.Add(i2);
                    mesh.TriangleIndices.Add(i1);

                    mesh.TriangleIndices.Add(i1);
                    mesh.TriangleIndices.Add(i2);
                    mesh.TriangleIndices.Add(i3);
                }
            }

            return mesh;
        }
    }
}
