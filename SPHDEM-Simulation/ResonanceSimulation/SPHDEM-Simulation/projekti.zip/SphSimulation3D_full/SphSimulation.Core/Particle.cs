// Particle.cs
using System.Numerics;

namespace SphSimulation.Core
{
    public struct Particle
    {
        public Vector3 Position;
        public Vector3 Velocity;
        public Vector3 Acceleration;

        public float Density;
        public float Pressure;
        public float Mass;

        public Particle(Vector3 position, float mass)
        {
            Position = position;
            Velocity = Vector3.Zero;
            Acceleration = Vector3.Zero;
            Density = 0f;
            Pressure = 0f;
            Mass = mass;
        }
    }
}
