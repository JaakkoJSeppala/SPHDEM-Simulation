// SphIntegrator3D.cs
using System.Collections.Generic;
using System.Numerics;
using System.Threading.Tasks;

namespace SphSimulation.Core
{
	internal class SphIntegrator3D
	{
		private readonly SphConfig cfg;
		private readonly Kernel3D kernel;
		private readonly NeighborSearch3D neighborSearch;

		public SphIntegrator3D(SphConfig cfg)
		{
			this.cfg = cfg;
			kernel = new Kernel3D(cfg.SmoothingLength);

			// K�ytet��n kernelin s�teen mittaa solukon solukokona
			neighborSearch = new NeighborSearch3D(cfg.KernelRadius);
		}

		public void Step(IList<Particle> particles, float dt)
		{
			neighborSearch.Build(particles);
			ComputeDensityAndPressure(particles);
			ComputeForces(particles);
			Integrate(particles, dt);
		}

		private void ComputeDensityAndPressure(IList<Particle> particles)
		{
			Parallel.For(0, particles.Count, i =>
			{
				var pi = particles[i];
				float rho = 0f;

				foreach (var j in neighborSearch.GetNeighbors(particles, i))
				{
					var pj = particles[j];
					float r = (pi.Position - pj.Position).Length();
					float w = kernel.W(r);
					rho += pj.Mass * w;
				}

				// self-term
				rho += pi.Mass * kernel.W(0f);

				pi.Density = rho;
				pi.Pressure = cfg.ComputePressure(rho);
				particles[i] = pi;
			});
		}

		private void ComputeForces(IList<Particle> particles)
		{
			Parallel.For(0, particles.Count, i =>
			{
				var pi = particles[i];
				Vector3 acc = cfg.Gravity;

				foreach (var j in neighborSearch.GetNeighbors(particles, i))
				{
					var pj = particles[j];
					Vector3 rij = pi.Position - pj.Position;
					float r = rij.Length();
					if (r <= 1e-5f)
						continue;

					float pTerm =
						(pi.Pressure / (pi.Density * pi.Density)) +
						(pj.Pressure / (pj.Density * pj.Density));

					Vector3 gradW = kernel.GradW(rij);
					Vector3 fPressure = -pj.Mass * pTerm * gradW;

					Vector3 vij = pj.Velocity - pi.Velocity;
					float w = kernel.W(r);
					Vector3 fVisc = cfg.Viscosity * pj.Mass * vij / pj.Density * w;

					acc += (fPressure + fVisc);
				}

				pi.Acceleration = acc;
				particles[i] = pi;
			});
		}

		private void Integrate(IList<Particle> particles, float dt)
		{
			Parallel.For(0, particles.Count, i =>
			{
				var p = particles[i];

				p.Velocity += p.Acceleration * dt;

				float speed = p.Velocity.Length();
				if (speed > cfg.MaxVelocity)
				{
					p.Velocity *= cfg.MaxVelocity / speed;
				}

				p.Position += p.Velocity * dt;

				particles[i] = p;
			});
		}
	}
}
