// Kernel3D.cs
using System;
using System.Numerics;

namespace SphSimulation.Core
{
    /// <summary>
    /// 3D Spiky-kernel:
    /// W(r) = 15/(π h^6) (h - r)^3, 0 &lt; r &lt;= h
    /// ∇W(r) = -45/(π h^6) (h - r)^2 * r̂
    /// </summary>
    public class Kernel3D
    {
        private readonly float h;
        private readonly float h6;
        private readonly float coeff;
        private readonly float gradCoeff;

        public Kernel3D(float smoothingLength)
        {
            h = smoothingLength;
            h6 = h * h * h * h * h * h;
            coeff = 15f / (MathF.PI * h6);
            gradCoeff = -45f / (MathF.PI * h6);
        }

        public float W(float r)
        {
            if (r >= h || r <= 0f)
                return 0f;

            float x = h - r;
            return coeff * x * x * x;
        }

        public Vector3 GradW(Vector3 rij)
        {
            float r = rij.Length();
            if (r <= 1e-6f || r >= h)
                return Vector3.Zero;

            float x = h - r;
            float factor = gradCoeff * x * x / r;
            return factor * rij;
        }
    }
}
