﻿// NeighborSearch3D.cs
using System;
using System.Collections.Generic;
using System.Numerics;

namespace SphSimulation.Core
{
	/// <summary>
	/// 3D-naapurihaku kiinteällä ruudukolla.
	/// Käyttö:
	///   1) neighborSearch.Build(particles);
	///   2) foreach (var j in neighborSearch.GetNeighbors(particles, i)) { ... }
	/// </summary>
	public class NeighborSearch3D
	{
		private readonly float cellSize;

		private int gridX, gridY, gridZ;
		private List<int>[] grid = Array.Empty<List<int>>();

		public NeighborSearch3D(float smoothingLength)
		{
			cellSize = smoothingLength;
		}

		/// <summary>
		/// Lasketaan simulaatioalueen karkea koko partikkelien perusteella
		/// ja varmistetaan, että ruudukko on oikean kokoinen.
		/// </summary>
		private void EnsureGrid(IList<Particle> particles)
		{
			if (particles.Count == 0)
			{
				gridX = gridY = gridZ = 1;
				if (grid.Length != 1)
					grid = new[] { new List<int>(0) };
				return;
			}

			float maxX = 0f, maxY = 0f, maxZ = 0f;

			for (int i = 0; i < particles.Count; i++)
			{
				var p = particles[i].Position;
				if (p.X > maxX) maxX = p.X;
				if (p.Y > maxY) maxY = p.Y;
				if (p.Z > maxZ) maxZ = p.Z;
			}

			// Pieni marginaali reunoille
			gridX = Math.Max(1, (int)(maxX / cellSize) + 3);
			gridY = Math.Max(1, (int)(maxY / cellSize) + 3);
			gridZ = Math.Max(1, (int)(maxZ / cellSize) + 3);

			int totalCells = gridX * gridY * gridZ;

			if (grid.Length != totalCells)
			{
				grid = new List<int>[totalCells];
				for (int i = 0; i < totalCells; i++)
					grid[i] = new List<int>(64); // vältetään roskankeruuta
			}
		}

		private int Index(int x, int y, int z)
		{
			return (x * gridY + y) * gridZ + z;
		}

		/// <summary>
		/// Rakentaa väliaikaisen ruudukon annetuista partikkeleista.
		/// Kutsu tätä kerran per simulaatioaskel ennen GetNeighbors-kutsuja.
		/// </summary>
		public void Build(IList<Particle> particles)
		{
			EnsureGrid(particles);

			// Tyhjennetään solut ilman uudelleenallokaatiota
			for (int i = 0; i < grid.Length; i++)
				grid[i].Clear();

			// Lisätään partikkelit oikeisiin soluihin
			for (int i = 0; i < particles.Count; i++)
			{
				var p = particles[i].Position;

				int ix = (int)(p.X / cellSize);
				int iy = (int)(p.Y / cellSize);
				int iz = (int)(p.Z / cellSize);

				ix = Math.Clamp(ix, 0, gridX - 1);
				iy = Math.Clamp(iy, 0, gridY - 1);
				iz = Math.Clamp(iz, 0, gridZ - 1);

				grid[Index(ix, iy, iz)].Add(i);
			}
		}

		/// <summary>
		/// Palauttaa annetun partikkelin naapurien indeksit
		/// (kaikki partikkelit 3x3x3 lähisoluissa).
		/// </summary>
		public IEnumerable<int> GetNeighbors(IList<Particle> particles, int i)
		{
			var p = particles[i].Position;

			int ix = (int)(p.X / cellSize);
			int iy = (int)(p.Y / cellSize);
			int iz = (int)(p.Z / cellSize);

			for (int x = ix - 1; x <= ix + 1; x++)
				for (int y = iy - 1; y <= iy + 1; y++)
					for (int z = iz - 1; z <= iz + 1; z++)
					{
						if (x < 0 || y < 0 || z < 0 ||
							x >= gridX || y >= gridY || z >= gridZ)
							continue;

						foreach (int j in grid[Index(x, y, z)])
						{
							if (j != i)
								yield return j;
						}
					}
		}
	}
}
