// SphConfig.cs
using System;
using System.Numerics;

namespace SphSimulation.Core
{
    public class SphConfig
    {
        public float RestDensity { get; set; } = 1000f;      // kg/m^3
        public float SoundSpeed { get; set; } = 20f;         // m/s
        public float Viscosity { get; set; } = 0.1f;         // Pa·s
        public float SmoothingLength { get; set; } = 0.05f;  // m
        public float ParticleMass { get; set; } = 0.0005f;   // kg
        public float TimeStep { get; set; } = 0.001f;        // s
        public float MaxVelocity { get; set; } = 5f;         // m/s

        public Vector3 Gravity { get; set; } = new Vector3(0, -9.81f, 0);

        public float KernelRadius => 2f * SmoothingLength;

        public float TaitGamma { get; set; } = 7.0f;

        public float TaitB => SoundSpeed * SoundSpeed * RestDensity / TaitGamma;

        public float ComputePressure(float density)
        {
            // Taitin yhtälö
            return TaitB * (float)Math.Pow(density / RestDensity, TaitGamma) - TaitB;
        }
    }
}
