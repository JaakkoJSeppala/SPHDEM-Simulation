// MainWindow.xaml.cs
using SphSimulation.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Threading;

namespace SphSimulation.Wpf
{
    public partial class MainWindow : Window
    {
        private SphSimulation3D sim = null!;
        private readonly List<TranslateTransform3D> transforms = new();
        private readonly DispatcherTimer timer = new();

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            InitializeSimulation();
            BuildParticles();

            timer.Interval = TimeSpan.FromMilliseconds(16);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void InitializeSimulation()
        {
            var cfg = new SphConfig
            {
                RestDensity = 1000f,
                SoundSpeed = 20f,
                Viscosity = 0.1f,
                SmoothingLength = 0.05f,
                ParticleMass = 0.0005f,
                TimeStep = 0.001f,
                MaxVelocity = 5f,
                Gravity = new Vector3(0, -9.81f, 0)
            };

            var boxMin = new Vector3(0, 0, 0);
            var boxMax = new Vector3(1, 1, 1);

            sim = new SphSimulation3D(cfg, boxMin, boxMax);
            sim.InitializeBoxFluid(fillHeight: 0.5f);
        }

        private void BuildParticles()
        {
            var particles = sim.Particles;
            var group = new Model3DGroup();

            var material = new DiffuseMaterial(new SolidColorBrush(Color.FromRgb(30, 144, 255)));

            double radius = 0.02;

            foreach (var p in particles)
            {
                var mesh = SphereMeshBuilder.CreateSphereMesh(
                    new Point3D(p.Position.X, p.Position.Y, p.Position.Z),
                    radius,
                    slices: 10,
                    stacks: 6);

                var model = new GeometryModel3D(mesh, material);
                var transform = new TranslateTransform3D(
                    p.Position.X,
                    p.Position.Y,
                    p.Position.Z);

                model.Transform = transform;
                transforms.Add(transform);
                group.Children.Add(model);
            }

            viewport.Children.Add(new ModelVisual3D { Content = group });
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            sim.Step(substeps: 5);
            var particles = sim.Particles;

            for (int i = 0; i < particles.Count && i < transforms.Count; i++)
            {
                transforms[i].OffsetX = particles[i].Position.X;
                transforms[i].OffsetY = particles[i].Position.Y;
                transforms[i].OffsetZ = particles[i].Position.Z;
            }
        }
    }
}
