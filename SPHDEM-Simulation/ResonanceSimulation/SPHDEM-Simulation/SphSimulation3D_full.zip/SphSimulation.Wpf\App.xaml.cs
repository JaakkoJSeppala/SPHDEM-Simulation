// App.xaml.cs
using System.Windows;

namespace SphSimulation.Wpf
{
    public partial class App : Application
    {
    }
}
