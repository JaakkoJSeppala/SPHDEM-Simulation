// SphSimulation3D.cs
using System.Collections.Generic;
using System.Numerics;

namespace SphSimulation.Core
{
    public class SphSimulation3D
    {
        private readonly SphConfig cfg;
        private readonly SphIntegrator3D integrator;
        private readonly List<Particle> particles = new();

        private readonly Vector3 boxMin;
        private readonly Vector3 boxMax;

        public IReadOnlyList<Particle> Particles => particles;

        public SphSimulation3D(SphConfig cfg, Vector3 boxMin, Vector3 boxMax)
        {
            this.cfg = cfg;
            this.boxMin = boxMin;
            this.boxMax = boxMax;
            integrator = new SphIntegrator3D(cfg);
        }

        public void InitializeBoxFluid(float fillHeight)
        {
            particles.Clear();

            float dx = cfg.SmoothingLength * 0.8f;
            for (float x = boxMin.X + dx; x <= boxMax.X - dx; x += dx)
            for (float y = boxMin.Y + dx; y <= fillHeight; y += dx)
            for (float z = boxMin.Z + dx; z <= boxMax.Z - dx; z += dx)
            {
                particles.Add(new Particle(new Vector3(x, y, z), cfg.ParticleMass));
            }
        }

        public void Step(int substeps = 1)
        {
            for (int s = 0; s < substeps; s++)
            {
                integrator.Step(particles, cfg.TimeStep);
                EnforceBoxBounds();
            }
        }

        private void EnforceBoxBounds()
        {
            for (int i = 0; i < particles.Count; i++)
            {
                var p = particles[i];
                var pos = p.Position;
                var vel = p.Velocity;

                if (pos.X < boxMin.X) { pos.X = boxMin.X; vel.X *= -0.5f; }
                if (pos.X > boxMax.X) { pos.X = boxMax.X; vel.X *= -0.5f; }

                if (pos.Y < boxMin.Y) { pos.Y = boxMin.Y; vel.Y *= -0.5f; }
                if (pos.Y > boxMax.Y) { pos.Y = boxMax.Y; vel.Y *= -0.5f; }

                if (pos.Z < boxMin.Z) { pos.Z = boxMin.Z; vel.Z *= -0.5f; }
                if (pos.Z > boxMax.Z) { pos.Z = boxMax.Z; vel.Z *= -0.5f; }

                p.Position = pos;
                p.Velocity = vel;
                particles[i] = p;
            }
        }
    }
}
