// NeighborSearch3D.cs
using System;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.CompilerServices;

namespace SphSimulation.Core
{
	public class NeighborSearch3D
	{
		private readonly float cellSize;
		private int gridX, gridY, gridZ;

		private List<int>[] grid = Array.Empty<List<int>>();

		public NeighborSearch3D(float smoothingLength)
		{
			cellSize = smoothingLength;
		}

		// --- Laskee ruudukon koon dynaamisesti ------------------------------
		private void EnsureGrid(Vector3[] pos)
		{
			float maxX = 0, maxY = 0, maxZ = 0;

			foreach (var p in pos)
			{
				if (p.X > maxX) maxX = p.X;
				if (p.Y > maxY) maxY = p.Y;
				if (p.Z > maxZ) maxZ = p.Z;
			}

			gridX = Math.Max(1, (int)(maxX / cellSize) + 2);
			gridY = Math.Max(1, (int)(maxY / cellSize) + 2);
			gridZ = Math.Max(1, (int)(maxZ / cellSize) + 2);

			int total = gridX * gridY * gridZ;

			if (grid.Length != total)
			{
				grid = new List<int>[total];
				for (int i = 0; i < grid.Length; i++)
					grid[i] = new List<int>(64);
			}
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private int Index(int x, int y, int z)
			=> (x * gridY + y) * gridZ + z;

		// --- Rakentaa ruudukon partikkelien perusteella --------------------
		public void Build(IList<Particle> particles)
		{
			var pos = new Vector3[particles.Count];
			for (int i = 0; i < pos.Length; i++)
				pos[i] = particles[i].Position;

			EnsureGrid(pos);

			foreach (var list in grid)
				list.Clear();

			for (int i = 0; i < pos.Length; i++)
			{
				int ix = (int)(pos[i].X / cellSize);
				int iy = (int)(pos[i].Y / cellSize);
				int iz = (int)(pos[i].Z / cellSize);

				ix = Math.Clamp(ix, 0, gridX - 1);
				iy = Math.Clamp(iy, 0, gridY - 1);
				iz = Math.Clamp(iz, 0, gridZ - 1);

				grid[Index(ix, iy, iz)].Add(i);
			}
		}

		// --- Palauttaa naapureiden indeksit (helppo k�ytt�liittym�) --------
		public IEnumerable<int> GetNeighbors(IList<Particle> particles, int i)
		{
			var p = particles[i].Position;

			int ix = (int)(p.X / cellSize);
			int iy = (int)(p.Y / cellSize);
			int iz = (int)(p.Z / cellSize);

			for (int x = ix - 1; x <= ix + 1; x++)
				for (int y = iy - 1; y <= iy + 1; y++)
					for (int z = iz - 1; z <= iz + 1; z++)
					{
						if (x < 0 || y < 0 || z < 0 ||
							x >= gridX || y >= gridY || z >= gridZ)
							continue;

						foreach (int j in grid[Index(x, y, z)])
							if (j != i)
								yield return j;
					}
		}
	}
}
